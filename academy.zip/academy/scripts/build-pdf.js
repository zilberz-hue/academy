#!/usr/bin/env node
/**
 * Render every course to A4 PDF: cover page, course contents, then the lessons.
 *
 *   npm run pdf
 *
 * Reads dist/standalone (built with embedded fonts) so the PDFs never fall back
 * to a system font, and writes pdf/<slug>.pdf.
 */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const ROOT = path.dirname(__dirname);
const SRC = path.join(ROOT, 'dist', 'standalone');
const OUT = path.join(ROOT, 'pdf');

// the sandboxed container ships Chromium here; elsewhere Playwright finds its own
const PINNED = '/opt/pw-browsers/chromium';

(async () => {
  if (!fs.existsSync(SRC)) {
    console.error('missing %s — run: npm run standalone', path.relative(ROOT, SRC));
    process.exit(1);
  }
  fs.mkdirSync(OUT, { recursive: true });

  const opts = fs.existsSync(PINNED) ? { executablePath: PINNED } : {};
  const browser = await chromium.launch(opts);

  const files = fs.readdirSync(SRC).filter((f) => f.endsWith('.html')).sort();
  for (const file of files) {
    const page = await browser.newPage();
    const errors = [];
    page.on('pageerror', (e) => errors.push(String(e).slice(0, 120)));

    await page.goto('file://' + path.join(SRC, file), { waitUntil: 'load', timeout: 90000 });
    await page.evaluate(() => document.fonts.ready);
    await page.waitForTimeout(1500);          // let the course-structure block build
    await page.emulateMedia({ media: 'print' });

    const out = path.join(OUT, file.replace('.html', '.pdf'));
    await page.pdf({
      path: out,
      format: 'A4',
      printBackground: true,
      margin: { top: '15mm', bottom: '17mm', left: '13mm', right: '13mm' },
    });

    const kb = Math.round(fs.statSync(out).size / 1024);
    console.log(
      '%s %s KB%s',
      path.basename(out).padEnd(22),
      String(kb).padStart(5),
      errors.length ? '  JS errors: ' + errors.join(' | ') : ''
    );
    await page.close();
  }

  await browser.close();
  console.log('\n-> %s', path.relative(ROOT, OUT));
})();
