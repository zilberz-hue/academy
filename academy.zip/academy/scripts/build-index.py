#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate index.html from courses.json, in the shared design language."""
import json, os, html, datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

GROUPS = [
    ('אבחון', 'היסודות — איך קוראים את המטופל'),
    ('קליני', 'מערכות הגוף — אבחון, פרוטוקולים ופורמולות'),
    ('עור',   'עור וקוסמטיקה — פנים, חוץ והקרמים'),
    ('כלים',  'כלים — מה שמסביב לקליניקה'),
]

PAGE = """<!doctype html>
<html lang="he" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>בית הספר של טיזון</title>
<meta name="description" content="קורסי רפואה סינית ונטורופתיה של ד״ר צחי זילבר">
<link rel="icon" href="assets/logo.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Frank+Ruhl+Libre:wght@400;500;700;900&family=Assistant:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap">
<link rel="stylesheet" href="assets/tizon.css">
<style id="tizon-course">
body{{min-height:100vh;display:flex;flex-direction:column}}
.wrap{{max-width:var(--tz-wrap);margin:0 auto;padding:0 24px;width:100%}}
.tz-hero{{padding:68px 24px 60px;text-align:center}}
.tz-hero .tz-logo{{margin-bottom:18px}}
.tz-hero .eyebrow{{font-size:12px;font-weight:600;letter-spacing:.2em;margin:0 0 12px}}
.tz-hero .lead{{max-width:620px;margin:14px auto 0;font-size:19px}}
main{{flex:1;padding:50px 0 20px}}
.group{{margin-bottom:46px}}
.group-head{{display:flex;align-items:baseline;gap:14px;margin-bottom:4px}}
.group-head h2{{font-size:25px;font-weight:700}}
.group-head .count{{font-family:var(--tz-mono);font-size:12px;color:var(--tz-bronze-deep);
  border:1px solid var(--tz-line-strong);border-radius:var(--tz-r-pill);padding:2px 10px}}
.group-note{{color:var(--tz-ink-mute);font-size:15px;margin:0 0 22px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:18px}}
.card{{position:relative;display:flex;flex-direction:column;gap:9px;background:var(--tz-card);
  border:1px solid var(--tz-line);border-radius:var(--tz-r-lg);padding:22px 22px 20px;
  transition:border-color .18s,box-shadow .18s,transform .18s}}
.card:hover{{border-color:var(--tz-leaf);box-shadow:var(--tz-sh);transform:translateY(-2px)}}
.card h3{{font-size:20px;font-weight:700;line-height:1.3;margin:0}}
.card h3 a{{color:inherit;text-decoration:none}}
.card h3 a::after{{content:"";position:absolute;inset:0;border-radius:var(--tz-r-lg)}}
.card p{{margin:0;color:var(--tz-ink-soft);font-size:15px;line-height:1.6;flex:1}}
.card .foot{{display:flex;align-items:center;gap:9px;margin-top:4px;
  font-family:var(--tz-mono);font-size:12px;color:var(--tz-bronze-deep)}}
.card .foot .dot{{width:5px;height:5px;border-radius:50%;background:var(--tz-leaf)}}
.card .pdf{{position:relative;z-index:1;margin-inline-start:auto;color:var(--tz-ink-mute);
  text-decoration:none;border:1px solid var(--tz-line);border-radius:var(--tz-r-pill);padding:2px 10px}}
.card .pdf:hover{{color:var(--tz-leaf-dark);border-color:var(--tz-leaf)}}
footer{{border-top:1px solid var(--tz-line);padding:26px 0 44px;text-align:center;
  color:var(--tz-ink-mute);font-size:14px}}
@media (max-width:640px){{.tz-hero{{padding:48px 20px 44px}}}}
</style>
</head>
<body>

<header class="tz-hero">
  <img class="tz-logo" src="assets/logo.png" alt="Tizon Health">
  <p class="eyebrow">TIZON HEALTH</p>
  <h1>בית הספר של טיזון</h1>
  <p class="lead">קורסי רפואה סינית, נטורופתיה וקוסמטיקה הוליסטית — ד״ר צחי זילבר</p>
  <div class="meta" style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:24px">
    <span class="chip">{n_courses} קורסים</span>
    <span class="chip">{n_units} שיעורים</span>
  </div>
</header>

<main class="wrap">
{groups}
</main>

<footer>
  ד״ר צחי זילבר · רפואה סינית מסורתית ונטורופתיה · drzilber.com
</footer>

</body>
</html>
"""

CARD = """      <article class="card">
        <h3><a href="courses/{slug}.html">{title}</a></h3>
        <p>{sub}</p>
        <div class="foot"><span class="dot"></span>{units} {unitLabel}
          <a class="pdf" href="pdf/{slug}.pdf">PDF</a></div>
      </article>"""


def main():
    data = json.load(open(os.path.join(ROOT, 'courses.json'), encoding='utf-8'))
    by = {}
    for c in data:
        by.setdefault(c['group'], []).append(c)

    blocks = []
    for key, note in GROUPS:
        items = by.get(key, [])
        if not items:
            continue
        cards = '\n'.join(CARD.format(**{k: html.escape(str(v)) for k, v in c.items()})
                          for c in items)
        blocks.append(
            '  <section class="group">\n'
            '    <div class="group-head"><h2>%s</h2><span class="count">%d</span></div>\n'
            '    <p class="group-note">%s</p>\n'
            '    <div class="grid">\n%s\n    </div>\n'
            '  </section>' % (html.escape(key), len(items), html.escape(note), cards))

    out = PAGE.format(groups='\n'.join(blocks),
                      n_courses=len(data),
                      n_units=sum(c['units'] for c in data))
    open(os.path.join(ROOT, 'index.html'), 'w', encoding='utf-8').write(out)
    print('index.html —', len(data), 'courses,', sum(c['units'] for c in data), 'units')


if __name__ == '__main__':
    main()
