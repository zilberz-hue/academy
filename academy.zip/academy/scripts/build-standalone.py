#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Inline the shared assets back into each course, producing self-contained files.

The repo keeps courses lean (they link to ../assets/). This produces one-file
copies for emailing, for an LMS upload, and as the input for the PDF build.

    python3 scripts/build-standalone.py            # -> dist/standalone/
    python3 scripts/build-standalone.py --fonts    # also embed the brand webfonts
"""
import os, re, sys, glob, base64, json

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT  = os.path.join(ROOT, 'dist', 'standalone')

FONT_FACES = [
    ('@fontsource/assistant',         'assistant',         'Assistant',
     (300, 400, 500, 600, 700, 800)),
    ('@fontsource/frank-ruhl-libre',  'frank-ruhl-libre',  'Frank Ruhl Libre',
     (400, 500, 700, 900)),
]


def font_css():
    """Inline the brand webfonts from node_modules, so PDFs never fall back."""
    faces = []
    for pkg, stem, family, weights in FONT_FACES:
        base = os.path.join(ROOT, 'node_modules', pkg, 'files')
        if not os.path.isdir(base):
            print('  ! %s not installed — run: npm install' % pkg)
            return ''
        for w in weights:
            for subset in ('hebrew', 'latin'):
                f = os.path.join(base, '%s-%s-%d-normal.woff2' % (stem, subset, w))
                if not os.path.exists(f):
                    continue
                b64 = base64.b64encode(open(f, 'rb').read()).decode()
                faces.append(
                    "@font-face{font-family:'%s';font-style:normal;font-weight:%d;"
                    "font-display:block;src:url(data:font/woff2;base64,%s) format('woff2')}"
                    % (family, w, b64))
    return '<style id="tz-fonts">' + ''.join(faces) + '</style>'


def main():
    want_fonts = '--fonts' in sys.argv
    os.makedirs(OUT, exist_ok=True)

    css  = open(os.path.join(ROOT, 'assets/tizon.css'), encoding='utf-8').read()
    toc  = open(os.path.join(ROOT, 'assets/toc.js'),    encoding='utf-8').read()
    logo = ('data:image/png;base64,' +
            base64.b64encode(open(os.path.join(ROOT, 'assets/logo.png'), 'rb').read()).decode())
    fonts = font_css() if want_fonts else ''

    for path in sorted(glob.glob(os.path.join(ROOT, 'courses', '*.html'))):
        name = os.path.basename(path)
        s = open(path, encoding='utf-8').read()

        s = s.replace('<link rel="stylesheet" href="../assets/tizon.css">',
                      '<style id="tizon-ds">\n' + css + '\n</style>')
        s = s.replace('<script src="../assets/toc.js" defer></script>',
                      '<script>' + toc + '</script>')
        s = s.replace('../assets/logo.png', logo)

        if fonts:
            s = re.sub(r'<link[^>]*fonts\.googleapis\.com/css2[^>]*>', fonts, s, count=1)
            if 'tz-fonts' not in s:
                s = s.replace('</head>', fonts + '</head>', 1)

        open(os.path.join(OUT, name), 'w', encoding='utf-8').write(s)
        print('%-20s %6d KB' % (name, len(s.encode()) // 1024))

    print('\n->', os.path.relpath(OUT, ROOT))


if __name__ == '__main__':
    main()
