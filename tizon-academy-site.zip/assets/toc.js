/* Tizon course design system — course-structure block.
   Builds the syllabus from the course's own content, so it can never
   drift from the lessons themselves. */
(function () {
  var C = window.__TZ_TOC__;
  if (!C || C.noToc) return;   // the course renders its own index

  function ready(fn) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }

  function clean(t) {
    return (t || '')
      .replace(/[\u{1F000}-\u{1FAFF}\u{2190}-\u{27BF}\u{FE0F}\u{2B00}-\u{2BFF}]/gu, '')
      .replace(/\s+/g, ' ')
      .replace(/^[\s·|\-–—]*\d+\s*[.·)\-–—]?\s*/, '')
      .trim();
  }

  function build() {
    var items = [].slice.call(document.querySelectorAll(C.item));
    if (!items.length) return;
    var navs = C.nav ? [].slice.call(document.querySelectorAll(C.nav)) : [];
    var mount = document.querySelector(C.mountAfter || C.mountIn);
    if (!mount) return;

    var sec = document.createElement('section');
    sec.className = 'tz-toc' + (C.printOnly ? ' tz-toc--print' : '');
    sec.id = 'tz-toc';

    var inner = document.createElement('div');
    inner.className = 'tz-toc-inner';

    var eye = document.createElement('p');
    eye.className = 'tz-toc-eyebrow';
    eye.textContent = C.eyebrow || 'מבנה הקורס';
    inner.appendChild(eye);

    var h = document.createElement('h2');
    h.textContent = C.title || 'תוכן הקורס';
    inner.appendChild(h);

    if (C.note) {
      var n = document.createElement('p');
      n.className = 'tz-toc-note';
      n.textContent = C.note.replace('{n}', items.length);
      inner.appendChild(n);
    }

    var ol = document.createElement('ol');

    // gather first, so near-identical descriptions can be dropped wholesale
    var rows = items.map(function (el, i) {
      var titleEl = C.title_sel ? el.querySelector(C.title_sel) : null;
      var label = clean(
        (titleEl && titleEl.textContent) ||
        (navs[i] && navs[i].textContent) ||
        el.getAttribute('data-title') || ''
      );
      if (!label) return null;

      var numEl = C.num_sel ? el.querySelector(C.num_sel) : null;
      var num = numEl ? clean(numEl.textContent).replace(/\D+/g, '') : '';
      if (!num) num = String(i + 1).padStart(2, '0');

      var subs = C.sub
        ? [].slice.call(el.querySelectorAll(C.sub))
            .map(function (s) { return clean(s.textContent); })
            .filter(function (s) { return s && s.length > 1 && s !== label; })
        : [];

      return { el: el, i: i, num: num, label: label,
               desc: subs.slice(0, C.subCount || 3).join(' · ') };
    }).filter(Boolean);

    if (!rows.length) return;

    // if most rows would carry the same description, it is boilerplate — drop it
    var seen = {}, top = 0;
    rows.forEach(function (r) { if (r.desc) { seen[r.desc] = (seen[r.desc] || 0) + 1; top = Math.max(top, seen[r.desc]); } });
    if (top > rows.length * 0.5) rows.forEach(function (r) { r.desc = ''; });

    rows.forEach(function (r) {
      var li = document.createElement('li');

      var num = document.createElement('span');
      num.className = 'tz-n';
      num.textContent = r.num;
      li.appendChild(num);

      var el = r.el, i = r.i;
      var btn = document.createElement(el.id ? 'a' : 'button');
      btn.className = 'tz-t';
      btn.textContent = r.label;
      if (el.id) btn.href = '#' + el.id;
      if (navs[i]) {
        btn.addEventListener('click', function (ev) {
          ev.preventDefault();
          navs[i].click();
          var target = el.id ? document.getElementById(el.id) : null;
          window.scrollTo({ top: target ? target.offsetTop - 20 : 0, behavior: 'smooth' });
        });
      }
      li.appendChild(btn);

      if (r.desc) {
        var d = document.createElement('span');
        d.className = 'tz-d';
        d.textContent = r.desc;
        li.appendChild(d);
      }
      ol.appendChild(li);
    });

    if (!ol.children.length) return;
    inner.appendChild(ol);
    sec.appendChild(inner);

    if (C.mountAfter) mount.parentNode.insertBefore(sec, mount.nextSibling);
    else mount.insertBefore(sec, mount.firstChild);
  }

  ready(function () { setTimeout(build, C.delay || 60); });
})();

/* Tizon course design system — lesson navigation.
   Renders one identical prev/next control at the foot of every lesson,
   built from the course's own lesson list. RTL: previous → , next ← */
(function () {
  var C = window.__TZ_TOC__;
  if (!C || C.noNav) return;

  function ready(fn) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }

  function clean(t) {
    return (t || '')
      .replace(/[\u{1F000}-\u{1FAFF}\u{2190}-\u{27BF}\u{FE0F}\u{2B00}-\u{2BFF}]/gu, '')
      .replace(/\s+/g, ' ')
      .replace(/^[\s·|\-–—]*\d+\s*[.·)\-–—]?\s*/, '')
      .trim();
  }

  function build() {
    var items = [].slice.call(document.querySelectorAll(C.item));
    if (items.length < 2) return;
    var navs = C.nav ? [].slice.call(document.querySelectorAll(C.nav)) : [];

    var titles = items.map(function (el, i) {
      var t = C.title_sel ? el.querySelector(C.title_sel) : null;
      return clean((t && t.textContent) || (navs[i] && navs[i].textContent) || '');
    });

    items.forEach(function (el, i) {
      if (el.querySelector(':scope > .tz-lessonnav')) return;

      var box = document.createElement('nav');
      box.className = 'tz-lessonnav';
      box.setAttribute('aria-label', 'ניווט בין שיעורים');

      [['prev', i - 1, 'הקודם', '→'], ['next', i + 1, 'הבא', '←']].forEach(function (d) {
        var dir = d[0], j = d[1], label = d[2], arrow = d[3];
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'tz-lessonnav-' + dir;
        if (j < 0 || j >= items.length) {
          btn.disabled = true;
          btn.innerHTML = '<span class="tz-ln-dir">' + arrow + ' ' + label + '</span>';
        } else {
          btn.innerHTML = '<span class="tz-ln-dir">' + arrow + ' ' + label + '</span>' +
                          '<span class="tz-ln-title">' + titles[j] + '</span>';
          btn.addEventListener('click', function () {
            if (navs[j]) {
              navs[j].click();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            } else {
              items[j].scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
          });
        }
        box.appendChild(btn);
      });

      el.appendChild(box);
    });
  }

  ready(function () { setTimeout(build, (C.delay || 60) + 120); });
})();
