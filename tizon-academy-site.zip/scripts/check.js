#!/usr/bin/env node
/**
 * Pre-deploy gate. Loads every course in a real browser and fails the build
 * if anything is actually broken — so a bad push never reaches the site.
 *
 *   node scripts/check.js
 *
 * Checks per course:
 *   · no JavaScript errors
 *   · no failed local requests (missing asset / wrong path)
 *   · the shared design system is live (parchment canvas, Assistant body)
 *   · exactly one course index visible on screen — no duplicates
 *   · the hero exists and carries the logo
 *   · the lesson count matches courses.json
 *   · no horizontal overflow
 * Plus: every link on index.html resolves to a file that exists.
 */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const ROOT = path.dirname(__dirname);
const PINNED = '/opt/pw-browsers/chromium';
const PARCHMENT = 'rgb(246, 242, 230)';

// how to count the teaching units of each course
const UNIT_SEL = {
  ai: '.mod', tongue: '.tab-content', skin: 'section.lesson',
  gynecology: 'article.lesson', orthopedics: '.lesson', digestive: 'section.module',
  winter: '.lesson', cosmetics: 'section.chapter', creams: '.card',
  moxa: 'section.mod', blood: '.lesson',
};
// courses whose unit count legitimately differs from courses.json
// (extra tools that are not teaching units)
const UNIT_EXTRA = { moxa: 3 };   // 9 מודולים + טבלת עזר, סוכן ומבחן

const problems = [];
const note = (course, msg) => problems.push(`${course}: ${msg}`);

(async () => {
  const meta = JSON.parse(fs.readFileSync(path.join(ROOT, 'courses.json'), 'utf8'));
  const opts = fs.existsSync(PINNED) ? { executablePath: PINNED } : {};
  const browser = await chromium.launch(opts);

  for (const course of meta) {
    const slug = course.slug;
    const file = path.join(ROOT, 'courses', slug + '.html');
    if (!fs.existsSync(file)) { note(slug, 'הקובץ חסר'); continue; }

    const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    const jsErrors = [];
    const missing = [];
    page.on('pageerror', (e) => jsErrors.push(String(e).split('\n')[0].slice(0, 120)));
    page.on('requestfailed', (r) => {
      const u = r.url();
      // webfonts and third-party CDNs are allowed to fail offline
      if (u.startsWith('file://')) missing.push(path.basename(u));
    });

    await page.goto('file://' + file, { waitUntil: 'load', timeout: 60000 });
    await page.evaluate(() => document.fonts.ready).catch(() => {});
    await page.waitForTimeout(1800);

    const r = await page.evaluate((sel) => {
      const cs = getComputedStyle(document.body);
      const seen = [];
      let indexes = 0;
      document
        .querySelectorAll('#tz-toc, .toc, .nav-card, nav.tabs, .sidebar-nav, #nav, nav.index')
        .forEach((el) => {
          const b = el.getBoundingClientRect();
          if (b.height > 80 && b.width > 0 && !seen.some((x) => x.contains(el))) {
            seen.push(el);
            indexes++;
          }
        });
      const hero = document.querySelector('.tz-hero');
      return {
        bg: cs.backgroundColor,
        font: cs.fontFamily.split(',')[0].replace(/["']/g, ''),
        hero: !!hero,
        heroLogo: !!(hero && hero.querySelector('img, [class*="logo"]')),
        units: sel ? document.querySelectorAll(sel).length : null,
        indexes,
        overflow: document.documentElement.scrollWidth > document.documentElement.clientWidth + 2,
      };
    }, UNIT_SEL[slug] || null);

    if (jsErrors.length) note(slug, 'שגיאות JS: ' + jsErrors.join(' | '));
    if (missing.length) note(slug, 'קבצים חסרים: ' + [...new Set(missing)].join(', '));
    if (r.bg !== PARCHMENT) note(slug, `רקע ${r.bg} במקום הקלף`);
    if (r.font !== 'Assistant') note(slug, `גופן הגוף ${r.font} במקום Assistant`);
    if (!r.hero) note(slug, 'אין hero');
    else if (!r.heroLogo) note(slug, 'אין לוגו ב-hero');
    if (r.indexes !== 1) note(slug, `${r.indexes} אינדקסים על המסך — צריך בדיוק אחד`);
    if (r.overflow) note(slug, 'גלילה אופקית');
    if (r.units !== null) {
      const expected = course.units + (UNIT_EXTRA[slug] || 0);
      if (r.units !== expected) {
        note(slug, `${r.units} יחידות בדף מול ${course.units} ב-courses.json`);
      }
    }

    console.log(
      `${slug.padEnd(13)} ${r.units ?? '—'} יח׳  אינדקס:${r.indexes}  ` +
        (jsErrors.length || missing.length ? '✗' : '✓')
    );
    await page.close();
  }

  // every link on the home page must point at a file that exists
  const index = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
  for (const m of index.matchAll(/href="([^"#:]+)"/g)) {
    const target = path.join(ROOT, m[1]);
    if (!fs.existsSync(target)) note('index.html', 'קישור שבור: ' + m[1]);
  }

  await browser.close();

  if (problems.length) {
    console.error('\n✗ ' + problems.length + ' בעיות:\n' + problems.map((p) => '  · ' + p).join('\n'));
    process.exit(1);
  }
  console.log('\n✓ כל הקורסים תקינים');
})();
